BetterErrors.editor = :sublime if defined? BetterErrors

