class Post < ApplicationRecord
	validates :content, presence:true
	belongs_to :user
	has_many :comments, dependent: :destroy

	has_attached_file :post_image, :default_url => "/images/normal/missing.png", styles: { medium: "300x300>", thumb: "100x100>" }, default_url: "/images/:style/missing.png"
  	validates_attachment_content_type :post_image, content_type: /\Aimage\/.*\z/

end
