class User < ActiveRecord::Base
  validates :firstname, presence: true
  # using valid_email
  validates :lastname, presence: true
  validates_uniqueness_of :email, :message => "must be unique"
  validates_length_of :password, :minimum => 6, :message => "must be more than 6 charater"
end
